<?php
require("function.php");
$resultat=all()

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="exo.css">
    <script src="E.js"></script>
</head>
<body>
<div class="container shadow-none p-2 mb-2 bg-light rounded">
    <table class="table">
  <thead class="thead-white">
    <tr>
      <th scope="col">id</th>
      <th scope="col">Date de creation</th>
      <th scope="col">Etat</th>
      <th scope="col">Nom</th>
      <th scope="col">Prénom</th>
      <th scope="col">Nom d'utilisateur</th>
      <th scope="col">Matricule</th>
      <th scope="col">Action</th>
      
    </tr>
  </thead>
    <tbody>
   <?php while($ligne=mysqli_fetch_assoc($resultat)) { ?>
       <tr>

    <th scope="row"><?=$ligne['id']?></th>
      <td><?=$ligne['creation']?></td>
      <td><?=$ligne['etat']?></td>
      <td><?=$ligne['nom']?></td>
      <td><?=$ligne['prenom']?></td>
      <td><?=$ligne['user']?></td>
      <td><?=$ligne['matricule']?></td>
      <td>
      <a onclick="return confirm('voulez vous vraiment supprimer?')" href="delete.php?id=<?=$ligne['id']?>" class="btn btn-outline">

      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
  <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
</svg>
      </a>
      </td>
    </tr>
    

</nav>
    </div>
    <?php } ?>
    </tbody>

    </table>
    </div>
    <div class="row">
    <div class="container shadow-none p-2 mb-4 bg-light rounded">
    <nav>
   <div id="us">
<a class="nav-link col-mb-3 tn btn-warning btn-sm " href="create.php">Ajouter Utilistaur</a>
</div>
</nav>
</div>
</div>
</body>
</html>