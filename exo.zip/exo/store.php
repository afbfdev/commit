<?php
require ("function.php");
//recuperer les datas
extract($_POST);
enregistrer($creation,$etat,$nom,$prenom,$user,$matricule);
// redirection vers index
header("location:index.php");
?>