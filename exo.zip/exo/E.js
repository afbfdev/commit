function maFonction(){
    let etat = document.querySelectorAll("etat"); 
    if (etat=> EnValidation){
    document.querySelectorAll("etat").style.backgroundColor = "orange";
}
if (etat=> Validé){
    document.querySelectorAll("etat").style.backgroundColor = "orange";
}
if (etat=> Rejeté){
    document.querySelectorAll("etat").style.backgroundColor = "orange";
}
    }


