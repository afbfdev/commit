<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nouveau </title>
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="exo.css">
</head>

<body>
<div class="container shadow-none p-5 mb-4 bg-light rounded">
 <div>
<h2>Ajout d'utilisateur</h2>
 </div>

        <form action="store.php" method="post">
 <div class=row>
 <div class="col-md-4 form-group"><label for="nom">Nom</label>
        <input required type="text" class="form-control" name="nom" id="nom" >
        </div>
        
        <div class="col-md-4 form-group"><label for="prenom">Prenom</label>
        <input required type="text" class="form-control" name="prenom" id="prenom" >
        </div>
        
         <div class="col-md-4 form-group"><label for="etat">Etat</label>
        <input required type="text" class="form-control" name="etat" id="etat" >
        </div>
        </div>
        <div class=row>
<div class="col-md-4 form-group"><label for="user">Nom d'utilisateur</label>
        <input type="" class="form-control" name="user" id="user">
        </div>
         <div class=" col-md-4 form-group"><label for="creation">Date de Creation</label>
        <input type="" class="form-control" name="creation" id="creation">
        </div>
    </div>
    <div class=row>
<div class="col-md-4 form-group"><label for="matricule">Matricule</label>
        <input type="text" class="form-control" name="matricule" id="matricule">
        </div>
     </div>
     <div id=en >
<button class="col-md-12 btn btn-warning btn-sm">Enregistrer</button>
</div>
        </form>
        </div>
    </div>

</div>

</body>
</html>