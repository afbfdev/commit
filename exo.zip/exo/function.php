<?php 
//connecter db 
 function connecter_db(){
  $link= mysqli_connect("localhost","root","","utilisateur") 
   or die("Erreur de connexion a la base de donnees ");
   return $link;
 }

// ajout
function enregistrer($creation,$etat,$nom,$prenom,$user,$matricule){
$link=connecter_db();
$requete=sprintf("insert into agent(creation,etat,nom,prenom,user,matricule) values('%s', '%s', '%s', '%s' , '%s' ,'%s')", $creation,$etat,$nom,$prenom,$user,$matricule);
mysqli_query($link,$requete) or die("Erreur d'ajout ".mysqli_error($link));
}

// supprimer

function delete($id){
// connexion db
$link=connecter_db();
//preparer la requete
$requete=sprintf("delete from agent where id=%d",$id);
// executer la requete
mysqli_query($link,$requete) or die("Erreur de suppression ".mysqli_error($link));

}
// lecture  des ressources 
function all(){
    $link=connecter_db();
    $requete="select * from agent" ;
 $resultat=   mysqli_query($link,$requete) or die("Erreur de selection des agent".mysqli_error($link));
return $resultat;    
}
